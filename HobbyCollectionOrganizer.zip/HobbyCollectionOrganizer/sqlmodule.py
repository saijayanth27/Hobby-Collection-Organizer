def create_in_memory_db():
    conn = sqlite3.connect(':memory:')  # In-memory database
    c = conn.cursor()

    # Create tables with new attributes
    c.execute('''CREATE TABLE sports (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    details TEXT,
                    date_added TEXT)''')

    c.execute('''CREATE TABLE books (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    author TEXT,
                    genre TEXT,
                    publication_year INTEGER)''')

    c.execute('''CREATE TABLE movies (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    director TEXT,
                    genre TEXT,
                    release_year INTEGER)''')

    return conn
